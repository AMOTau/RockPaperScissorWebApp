package za.ac.tut.model;

/**
 *
 * @author ALICIA TAU
 */
public interface RockPaperScissorInterface {
    public char generateSign();
    public String determineOutcome(char playerSign, char computerSign);
}
